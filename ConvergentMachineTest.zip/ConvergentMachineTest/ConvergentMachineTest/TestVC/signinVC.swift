//
//  signinVC.swift
//  ConvergentMachineTest
//
//  Created by Sonu_Gupta on 22/02/21.
//  Copyright © 2021 Sonu_Gupta. All rights reserved.
//

import UIKit

class signinVC: UIViewController {
    
    

    @IBOutlet weak var signintableView: UITableView!
    @IBOutlet weak var rememberBtn: UIButton!
    @IBOutlet weak var checkboxBtn: UIButton!
    @IBOutlet weak var forgotBtn: UIButton!
    @IBOutlet weak var signininBtn: UIButton!
    @IBOutlet weak var backView: UIView!
    @IBOutlet weak var googlebackView: UIView!
    
    
    let imgarray = [UIImage(named: "nameicon"), UIImage(named: "key")]
    let placeholder = ["Name","Password"]
    var obj = signInModal()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       signintableView.delegate = self
       signintableView.dataSource = self
       checkboxBtn.layer.cornerRadius = 2
        
       backView.layer.shadowColor = UIColor.lightGray.cgColor
       backView.layer.shadowOpacity = 0.7
       backView.layer.shadowOffset = .zero
       backView.layer.shadowRadius = 5
       backView.layer.shadowPath = UIBezierPath(rect: backView.bounds).cgPath
        
       googlebackView.layer.shadowColor = UIColor.lightGray.cgColor
       googlebackView.layer.shadowOpacity = 0.7
       googlebackView.layer.shadowOffset = .zero
       googlebackView.layer.shadowRadius = 5
       googlebackView.layer.shadowPath = UIBezierPath(rect: backView.bounds).cgPath

       
    }
    

  @IBAction func rememberMeTapped(_ sender: UIButton) {
         
         if sender.isSelected
         {
             sender.isSelected = false
         }
         else
         {
             sender.isSelected = true
         }
     }
    
    
    @IBAction func signInBtnAction(_ sender: UIButton) {

     

        if self.validateAllFields() {

            let createanaccount = self.storyboard?.instantiateViewController(withIdentifier: "HomeVC") as! HomeVC
            self.navigationController?.pushViewController(createanaccount, animated: true)

        }

    }

    @IBAction func signupbtnTapped(_ sender: Any) {
        
       let createanaccount = self.storyboard?.instantiateViewController(withIdentifier: "SignUpVC") as! SignUpVC
          self.navigationController?.pushViewController(createanaccount, animated: true)
    }
}

//MARK: - UITableview Datasource and delegate Action

extension signinVC: UITableViewDataSource, UITableViewDelegate {


func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return 2
}

func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    switch indexPath.row {
    default:
       let signin = tableView.dequeueReusableCell(withIdentifier: "signinTVCell", for: indexPath) as! signinTVCell
       signin.commonTextfiled.tag = indexPath.row + 100
       signin.logoimageView.image = imgarray[indexPath.row]
       signin.commonTextfiled.placeholder = placeholder[indexPath.row]
        signin.commonTextfiled.keyboardType = UIKeyboardType.default
       signin.commonTextfiled.delegate = self
    if indexPath.row == 0{
   
        // Name
        signin.commonTextfiled.autocapitalizationType = .words
        signin.commonTextfiled.returnKeyType = .next
        signin.commonTextfiled.text = obj.strName
        signin.commonTextfiled.delegate = self
        return signin
    }
   if indexPath.row == 1{
        // Password
        signin.commonTextfiled.returnKeyType = .next
        signin.commonTextfiled.text = obj.strPassword
        signin.commonTextfiled.delegate = self
        return signin
    }
   return signin
    }
}

}


//MARK: - Validation Funtion
extension signinVC {
    func validateAllFields() -> Bool {

        var isValid = false


        if obj.strName.count == 0 {

            obj.errorIndex = 0

            obj.strErrorMsg = "*Please enter your name."
            
            let cell : signinTVCell = (signintableView.cellForRow(at: IndexPath(row: 0, section: 0)) as? signinTVCell )!
            cell.labelError.text = obj.strErrorMsg
            self.signintableView.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: true)

           

        }

        else if  obj.strPassword.count == 0{

            obj.errorIndex = 1

            obj.strErrorMsg = "*Please enter your password."
            let cell : signinTVCell = (signintableView.cellForRow(at: IndexPath(row: 1, section: 0)) as? signinTVCell )!
            cell.labelError.text = obj.strErrorMsg
            self.signintableView.scrollToRow(at: IndexPath(row: 1, section: 0), at: .top, animated: true)

        }

        else{

            isValid = true

            obj.errorIndex = -1

            obj.strErrorMsg = ""

        }
   self.signintableView.reloadData()

        return isValid

    }



}



//Mark:- Validation
extension signinVC: UITextFieldDelegate{
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool{
        
        if  let text = textField.text as NSString? {
            
            let txtAfterUpdate = text.replacingCharacters(in: range, with: string)
            let numUpdate = txtAfterUpdate.count
            
            
            switch textField.tag - 100 {
            case 0:
                obj.strName = txtAfterUpdate
                if numUpdate > 50 || (textField.textInputMode?.primaryLanguage == "emoji")
                {
                    return false
                }
                if range.location == 0 && (string == " "){
                    return false
                }
                else
                {
                    let allOverChar = CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ")
                    let characterSet = CharacterSet(charactersIn: string)
                    if numUpdate == 0{
                        let cell : signinTVCell = (signintableView.cellForRow(at: IndexPath(row: 0, section: 0)) as? signinTVCell)!
                        cell.labelError.text = "*Please enter your name."
                    }
                    else if numUpdate == 1{
                        let cell : signinTVCell = (signintableView.cellForRow(at: IndexPath(row: 0, section: 0)) as? signinTVCell)!
                        cell.labelError.text = "*Please enter valid  name."
                        
                    }else {
                        let cell : signinTVCell = (signintableView.cellForRow(at: IndexPath(row: 0, section: 0)) as? signinTVCell)!
                        cell.labelError.text = ""
                        
                    }
                    return allOverChar.isSuperset(of: characterSet)
                }
            case 1:
                obj.strPassword = txtAfterUpdate
                if numUpdate > 50 || (textField.textInputMode?.primaryLanguage == "emoji")
                {
                    return false
                }
                if range.location == 0 && (string == " "){
                    return false
                }
                else
                {
                    
                    if numUpdate == 0{
                        let cell : signinTVCell = (signintableView.cellForRow(at: IndexPath(row: 1, section: 0)) as? signinTVCell)!
                        cell.labelError.text = "*Please enter your password"
                    }
                else if numUpdate <= 8 {
                        let cell : signinTVCell = (signintableView.cellForRow(at: IndexPath(row: 1, section: 0)) as? signinTVCell)!
                        cell.labelError.text = "*Password enter valid password."
                                               
                                           }
                    else {
                        let cell : signinTVCell = (signintableView.cellForRow(at: IndexPath(row: 1, section: 0)) as? signinTVCell)!
                        cell.labelError.text = ""
                        
                    }
                    
                }
                
            default:
                if textField.tag == 200 {
                    let maxLength = 8
                    let currentString: NSString = textField.text! as NSString
                    let newString: NSString =
                        currentString.replacingCharacters(in: range, with: string) as NSString
                    return newString.length <= maxLength
                }
                //
                return true
            } }
        
        return true
    }
    
}




//MARK:- signinVC Modal



class signInModal : NSObject {

    

    var strErrorMsg = ""
    var errorIndex = -1
    var strName = ""
    var strPassword = ""

}

 
