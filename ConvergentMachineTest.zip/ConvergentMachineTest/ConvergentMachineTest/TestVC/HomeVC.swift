//
//  HomeVC.swift
//  ConvergentMachineTest
//
//  Created by Sonu_Gupta on 23/02/21.
//  Copyright © 2021 Sonu_Gupta. All rights reserved.
//

import UIKit

class HomeVC: UIViewController {
    
    @IBOutlet weak var totalStudent: UIButton!
    @IBOutlet weak var experianceBtn: UIButton!
    @IBOutlet weak var toughtBtn: UIButton!
    @IBOutlet weak var pasttraining: UIButton!
    @IBOutlet weak var activetrainig: UIButton!
    @IBOutlet weak var addtoFavourite: UIButton!
    @IBOutlet weak var hometableView: UITableView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        hometableView.delegate = self
        hometableView.dataSource = self
        totalStudent.layer.cornerRadius = 20
        experianceBtn.layer.cornerRadius = 20
        toughtBtn.layer.cornerRadius = 20
        pasttraining.layer.cornerRadius = 20
        activetrainig.layer.cornerRadius = 20
        addtoFavourite.layer.cornerRadius = 3
        
    }
    


}


//MARK: - UITableview Datasource and delegate Action

extension HomeVC: UITableViewDataSource, UITableViewDelegate {


func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return 8
}

func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    
    switch indexPath.row {
    case 0:
         let home = tableView.dequeueReusableCell(withIdentifier: "homeaboutmeTVCell", for: indexPath) as! homeaboutmeTVCell
           return home
        
    case 1:
        let upcommingtraining = tableView.dequeueReusableCell(withIdentifier: "upcomingTrainingTVCell", for: indexPath) as! upcomingTrainingTVCell
        
          return upcommingtraining
        
        case 2:
               let reviews = tableView.dequeueReusableCell(withIdentifier: "ReviewsTVCell", for: indexPath) as! ReviewsTVCell
               
                 return reviews
        
    case 3...4,5,6,7:
               let reviewsdetals = tableView.dequeueReusableCell(withIdentifier: "reviewsdetailsTVCell", for: indexPath) as! reviewsdetailsTVCell
              
                 return reviewsdetals
    default:
        break
    }
    
    return UITableViewCell()
   
    
}
    

}


