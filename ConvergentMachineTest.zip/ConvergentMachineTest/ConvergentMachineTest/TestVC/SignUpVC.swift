//
//  SignUpVC.swift
//  ConvergentMachineTest
//
//  Created by Sonu_Gupta on 23/02/21.
//  Copyright © 2021 Sonu_Gupta. All rights reserved.
//

import UIKit

class SignUpVC: UIViewController {
       @IBOutlet weak var signintableView: UITableView!
       @IBOutlet weak var rememberBtn: UIButton!
       @IBOutlet weak var checkboxBtn: UIButton!
       @IBOutlet weak var forgotBtn: UIButton!
       @IBOutlet weak var signininBtn: UIButton!
       @IBOutlet weak var backView: UIView!
       @IBOutlet weak var googlebackView: UIView!
       
       var obj = signUpModal()
       let imgarray = [UIImage(named: "nameicon"), UIImage(named: "key"), UIImage(named: "key")]
       let placeholder = ["Name","Email","Password"]
       
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        signintableView.delegate = self
        signintableView.dataSource = self
        checkboxBtn.layer.cornerRadius = 2
               
        backView.layer.shadowColor = UIColor.lightGray.cgColor
        backView.layer.shadowOpacity = 0.7
        backView.layer.shadowOffset = .zero
        backView.layer.shadowRadius = 5
        backView.layer.shadowPath = UIBezierPath(rect: backView.bounds).cgPath
               
        googlebackView.layer.shadowColor = UIColor.lightGray.cgColor
        googlebackView.layer.shadowOpacity = 0.7
        googlebackView.layer.shadowOffset = .zero
        googlebackView.layer.shadowRadius = 5
        googlebackView.layer.shadowPath = UIBezierPath(rect: backView.bounds).cgPath
       
    }
    
      @IBAction func rememberMeTapped(_ sender: UIButton) {
             
             if sender.isSelected
             {
                 sender.isSelected = false
             }
             else
             {
                 sender.isSelected = true
             }
         }
        
        
        @IBAction func signInBtnAction(_ sender: UIButton) {

         

            if self.validateAllFields() == true {
                    self.webservicesAPICalltoSignUP()


            }

        }
    @IBAction func signinbtnTapped(_ sender: Any) {
           
         
             self.navigationController?.popViewController(animated: true)
       }

    }


    



//MARK: - UITableview Datasource and delegate Action

extension SignUpVC: UITableViewDataSource, UITableViewDelegate {


func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return 3
}

func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    switch indexPath.row {
    default:
         let signup = tableView.dequeueReusableCell(withIdentifier: "SignUpTVCell", for: indexPath) as! SignUpTVCell
           signup.logoimageView.image = imgarray[indexPath.row]
           signup.commonTextfiled.placeholder = placeholder[indexPath.row]
           signup.commonTextfiled.delegate = self
           signup.commonTextfiled.tag = indexPath.row + 100
    
    if  indexPath.row == 0 {
  
        // Name
        signup.commonTextfiled.autocapitalizationType = .words
        signup.commonTextfiled.text = obj.strName
        signup.commonTextfiled.returnKeyType = .next
        return signup
        }
         if indexPath.row == 1{
        // Email
        signup.commonTextfiled.keyboardType = .emailAddress
        signup.commonTextfiled.text = obj.stremail
        signup.commonTextfiled.returnKeyType = .next
        return signup
        }
         if indexPath.row == 2{
        // Password
        signup.commonTextfiled.text = obj.strPassword
        signup.commonTextfiled.returnKeyType = .next
        return signup
        }
    return signup
    }
  
}
    

}

//MARK: - Validation Funtion
extension SignUpVC {
    func validateAllFields() -> Bool {

        var isValid = false


        if obj.strName.count == 0 {

            obj.errorIndex = 0

            obj.strErrorMsg = "*Please enter your name."
            let cell : SignUpTVCell = (signintableView.cellForRow(at: IndexPath(row: 0, section: 0)) as? SignUpTVCell )!
            cell.labelError.text = obj.strErrorMsg
            self.signintableView.scrollToRow(at: IndexPath(row: 0, section: 0), at: .top, animated: true)

        }

        else if  obj.stremail.count == 0{

            obj.errorIndex = 1

            obj.strErrorMsg = "*Please enter your email address."
            let cell : SignUpTVCell = (signintableView.cellForRow(at: IndexPath(row: 1, section: 0)) as? SignUpTVCell )!
            cell.labelError.text = obj.strErrorMsg
            self.signintableView.scrollToRow(at: IndexPath(row: 1, section: 0), at: .top, animated: true)

        }
            else if  obj.strPassword.count == 0{

                obj.errorIndex = 2

                obj.strErrorMsg = "*Please enter your password."
            let cell : SignUpTVCell = (signintableView.cellForRow(at: IndexPath(row: 2, section: 0)) as? SignUpTVCell )!
            cell.labelError.text = obj.strErrorMsg
                self.signintableView.scrollToRow(at: IndexPath(row: 2, section: 0), at: .top, animated: true)

            }
            
        
        else{

            isValid = true

            obj.errorIndex = -1

            obj.strErrorMsg = ""

        }
   self.signintableView.reloadData()

        return isValid

    }

    

}
//Mark:- Validation UITextfiledDelegate
extension SignUpVC: UITextFieldDelegate{
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool{
        
        if  let text = textField.text as NSString? {
            
            let txtAfterUpdate = text.replacingCharacters(in: range, with: string)
            let numUpdate = txtAfterUpdate.count
            
            
            switch textField.tag - 100 {
            case 0:
                obj.strName = txtAfterUpdate
                if numUpdate > 50 || (textField.textInputMode?.primaryLanguage == "emoji")
                {
                    return false
                }
                if range.location == 0 && (string == " "){
                    return false
                }
                else
                {
                    let allOverChar = CharacterSet(charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz ")
                    let characterSet = CharacterSet(charactersIn: string)
                    if numUpdate == 0{
                        let cell : SignUpTVCell = (signintableView.cellForRow(at: IndexPath(row: 0, section: 0)) as? SignUpTVCell)!
                        cell.labelError.text = "*Please enter your name."
                    }
                    else {
                        let cell : SignUpTVCell = (signintableView.cellForRow(at: IndexPath(row: 0, section: 0)) as? SignUpTVCell)!
                        cell.labelError.text = ""
                        
                    }
                    return allOverChar.isSuperset(of: characterSet)
                }
                
                case 1:
                             obj.stremail = txtAfterUpdate
                             _ = isAllFieldForEmail()
                             if let cell : SignUpTVCell = signintableView.cellForRow(at: IndexPath(row: 1, section: 0)) as? SignUpTVCell
                             {
                                if(obj.errorIndex == 1)
                                 {
                                    cell.labelError.text = obj.strErrorMsg
                                 }
                                 else if (txtAfterUpdate.count > 64){
                                     textField.resignFirstResponder()
                                 }
                                 else
                                 {
                                     cell.labelError.text = ""
                                 }
                             }
                             return true
            case 2:
                obj.strPassword = txtAfterUpdate
                if numUpdate > 50 || (textField.textInputMode?.primaryLanguage == "emoji")
                {
                    return false
                }
                if range.location == 0 && (string == " "){
                    return false
                }
                else
                {
                    
                    if numUpdate == 0{
                        let cell : SignUpTVCell = (signintableView.cellForRow(at: IndexPath(row: 2, section: 0)) as? SignUpTVCell)!
                        cell.labelError.text = "*Please enter your password."
                    }
                else if numUpdate <= 8 {
                let cell : SignUpTVCell = (signintableView.cellForRow(at: IndexPath(row: 2, section: 0)) as? SignUpTVCell)!
                cell.labelError.text = "*Password enter valid password."
                                               
                                           }
                    else {
                        let cell : SignUpTVCell = (signintableView.cellForRow(at: IndexPath(row: 2, section: 0)) as? SignUpTVCell)!
                        cell.labelError.text = ""
                        
                    }
                    
                }
                
            default:
                if textField.tag == 200 {
                    let maxLength = 8
                    let currentString: NSString = textField.text! as NSString
                    let newString: NSString =
                        currentString.replacingCharacters(in: range, with: string) as NSString
                    return newString.length <= maxLength
                }
                //
                return true
            } }
        
        return true
    }
    
}


extension SignUpVC {

func isAllFieldForEmail() -> Bool {

    var isVerified = false

    if obj.stremail.count == 0 {

        obj.errorIndex = 1

        obj.strErrorMsg = "*Please enter your email address."

    }

    else {

        isVerified = true

        obj.errorIndex = 1

        obj.strErrorMsg = ""

        let isValid = isValidEmail(testStr: obj.stremail)

        if isValid {



        } else {

            isVerified = false

             obj.errorIndex = 1

             obj.strErrorMsg = "*Please enter a valid email id."

        }

    }

    return isVerified

}

func isValidEmail(testStr:String) -> Bool {
 let emailRegEx = "^(((([a-zA-Z]|\\d|[!#\\$%&'\\*\\+\\-\\/=\\?\\^_`{\\|}~]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])+(\\.([a-zA-Z]|\\d|[!#\\$%&'\\*\\+\\-\\/=\\?\\^_`{\\|}~]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])+)*)|((\\x22)((((\\x20|\\x09)*(\\x0d\\x0a))?(\\x20|\\x09)+)?(([\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x7f]|\\x21|[\\x23-\\x5b]|[\\x5d-\\x7e]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])|(\\([\\x01-\\x09\\x0b\\x0c\\x0d-\\x7f]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}]))))*(((\\x20|\\x09)*(\\x0d\\x0a))?(\\x20|\\x09)+)?(\\x22)))@((([a-zA-Z]|\\d|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])|(([a-zA-Z]|\\d|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])([a-zA-Z]|\\d|-|\\.|_|~|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])*([a-zA-Z]|\\d|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])))\\.)+(([a-zA-Z]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])|(([a-zA-Z]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])([a-zA-Z]|\\d|-|_|~|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])*([a-zA-Z]|[\\x{00A0}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFEF}])))\\.?$"

    let email = NSPredicate(format:"SELF MATCHES %@", emailRegEx)

    let result = email.evaluate(with: testStr)

    return result

}
}
//MARK:- OTServiceRequestPopUpVC Modal
class signUpModal : NSObject {
   var strErrorMsg = ""
    var errorIndex = -1
    var strName = ""
    var strPassword = ""
    var stremail = ""

}

//Webservices api call For signup
extension SignUpVC {
    
    func webservicesAPICalltoSignUP() {
        
        var params = [String:Any]()
        params["fname"] = obj.strName
        params["email"] = obj.stremail
        params["password"] = obj.strPassword
        
        ServiceHelper.request(params, method: .post, apiName: API_SIGNUP , hudType: .simple) { (result, error, code) in
            if result == nil{  _ = AlertController.alert("", message: "Something went wrong.");return}
            
            let responseDict = result as! [String:Any]
            let responseMessage = responseDict.validatedValue("responseMessage", expected:"" as AnyObject) as! String
            let StatusCode = responseDict.validatedValue("statusCode", expected:0 as AnyObject) as! Int
            
            if StatusCode == 200
            {
                  //Banner data
                
                let id = responseDict.validatedValue("id", expected: "" as AnyObject) as! String
                 UserDefaults.standard.set(id, forKey: "User_id")
                UserDefaults.standard.set(true, forKey: "IS_GUEST_USER")
                UserDefaults.standard.synchronize()
                let vc = UIStoryboard.init(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: "signinVC") as? signinVC
                self.navigationController?.pushViewController(vc!, animated: true)
                Debug.log("Products response Data  \(responseDict)")
                
              
            }else
            {
                _ = AlertController.alert("", message: responseMessage)
            }
        }
        
    }
    
}
