//
//  upcomingTrainingTVCell.swift
//  ConvergentMachineTest
//
//  Created by Sonu_Gupta on 23/02/21.
//  Copyright © 2021 Sonu_Gupta. All rights reserved.
//

import UIKit

class upcomingTrainingTVCell: UITableViewCell {
    
    @IBOutlet weak var upcommingtrsiningcollectionView: UICollectionView!
    @IBOutlet weak var pageControlers: UIPageControl!
    var logoImagess: [UIImage] = [UIImage(named: "rabinchhtarji")!,UIImage(named: "rabinchhtarji")!,UIImage(named: "rabinchhtarji")!,UIImage(named: "rabinchhtarji")!]
    var timer = Timer()
    var counter = 0
    override func awakeFromNib() {
        super.awakeFromNib()
        upcommingtrsiningcollectionView.delegate = self
        upcommingtrsiningcollectionView.dataSource = self
        pageControlers.numberOfPages = logoImagess.count
        pageControlers.currentPage = 0
        pageControlers.subviews.forEach {
        $0.transform = CGAffineTransform(scaleX: 20, y: 20)
       }
        DispatchQueue.main.async {
            self.timer = Timer.scheduledTimer(timeInterval: 3.0, target: self, selector: #selector(self.ChangeImage), userInfo: nil, repeats: true)
        }
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }
    
    @objc func ChangeImage(){
           if counter <  logoImagess.count{
               counter = counter + 1
               let index = IndexPath.init(item: counter, section: 0)
               self.upcommingtrsiningcollectionView.scrollToItem(at: index, at: .centeredHorizontally, animated: true)
               pageControlers.currentPage = counter
           }else{
               counter = 0
               let index = IndexPath.init(item: counter, section: 0)
               self.upcommingtrsiningcollectionView.scrollToItem(at: index, at: .centeredHorizontally, animated: true)
               pageControlers.currentPage = counter
           }
           
       }

}

extension upcomingTrainingTVCell: UICollectionViewDataSource, UICollectionViewDelegate{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return logoImagess.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let upcoming = collectionView.dequeueReusableCell(withReuseIdentifier: "UpcomingTrainingCVCell", for: indexPath) as! UpcomingTrainingCVCell
           upcoming.imageView.image = logoImagess[indexPath.item]
        return upcoming
    }
    
    
}

