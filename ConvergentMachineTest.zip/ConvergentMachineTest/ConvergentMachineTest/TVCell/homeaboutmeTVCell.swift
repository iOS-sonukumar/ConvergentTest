//
//  homeaboutmeTVCell.swift
//  ConvergentMachineTest
//
//  Created by Sonu_Gupta on 23/02/21.
//  Copyright © 2021 Sonu_Gupta. All rights reserved.
//

import UIKit

class homeaboutmeTVCell: UITableViewCell {
     @IBOutlet weak var aboutbackView: UIView!
    override func awakeFromNib() {
        super.awakeFromNib()
        
        aboutbackView.layer.shadowColor = UIColor.lightGray.cgColor
        aboutbackView.layer.shadowOpacity = 0.7
        aboutbackView.layer.shadowOffset = .zero
        aboutbackView.layer.shadowRadius = 5
        aboutbackView.layer.shadowPath = UIBezierPath(rect: aboutbackView.bounds).cgPath
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
