//
//  signinTVCell.swift
//  ConvergentMachineTest
//
//  Created by Sonu_Gupta on 22/02/21.
//  Copyright © 2021 Sonu_Gupta. All rights reserved.
//

import UIKit

class signinTVCell: UITableViewCell {
    @IBOutlet weak var logoimageView: UIImageView!
    @IBOutlet weak var commonTextfiled: UITextField!
    @IBOutlet weak var labelError: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
