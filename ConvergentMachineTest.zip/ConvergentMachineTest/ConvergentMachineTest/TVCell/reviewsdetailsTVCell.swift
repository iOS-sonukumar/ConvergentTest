//
//  reviewsdetailsTVCell.swift
//  ConvergentMachineTest
//
//  Created by Sonu_Gupta on 23/02/21.
//  Copyright © 2021 Sonu_Gupta. All rights reserved.
//

import UIKit

class reviewsdetailsTVCell: UITableViewCell {
    
       @IBOutlet weak var rabbinimageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        rabbinimageView.layer.cornerRadius = rabbinimageView.frame.size.height/2
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
