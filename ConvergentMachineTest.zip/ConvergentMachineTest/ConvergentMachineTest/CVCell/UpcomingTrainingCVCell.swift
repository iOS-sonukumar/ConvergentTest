//
//  UpcomingTrainingCVCell.swift
//  ConvergentMachineTest
//
//  Created by Sonu_Gupta on 23/02/21.
//  Copyright © 2021 Sonu_Gupta. All rights reserved.
//

import UIKit

class UpcomingTrainingCVCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
}
